import * as React from 'react';
import { Text, View, StyleSheet, FlatList, Pressable, Image,Modal } from 'react-native';
import Constants from 'expo-constants';


const ShowDetalhes = ({display,toogleModal,mensagem}) => (   
    <Modal
          animationType="slide"
          transparent={true}
          visible={display}
          onRequestClose={toogleModal}
    >

        <View style={styles.centeredView}>
          <View style={styles.modalView}>
                <Pressable onPress={toogleModal}>
                  <Text>{mensagem}</Text>
                </Pressable>
          </View>
        </View>
    
    </Modal>
        
 )

const Pessoa = ({nome,email,link}) => {

    //state para controle do Modal
    const [modal,setModal] = React.useState(false)

    function mudaModal(){
      setModal(!modal)
    }

    return(
    <View>
      <ShowDetalhes display={modal} toogleModal={mudaModal} mensagem={email}/>
      
      <Pressable onPress={mudaModal}>
        <Image
          style={styles.tinyLogo}
          source={{
            uri: link,
          }}
        />

        <Text style={styles.paragraph}>{nome}</Text>
      </Pressable>
    </View>
    )
}


const DATA = [
        {
            "id": 7,
            "email": "cr7@hotmail.com",
            "first_name": "Cristiano",
            "last_name": "Ronaldo",
            "avatar": "https://s2.glbimg.com/zRF2O_-s-Oeq2_SG4e8nSkUJPt8=/0x0:4213x2906/984x0/smart/filters:strip_icc()/i.s3.glbimg.com/v1/AUTH_bc8228b6673f488aa253bbcb03c80ec5/internal_photos/bs/2021/m/7/6ngAjGSu2jBJmBTRPHsg/2021-09-11t152203z-1863027115-up1eh9b16oqhs-rtrmadp-3-soccer-england-mun-new-report.jpg"
        },
        {
            "id": 8,
            "email": "messi@hotmail.com",
            "first_name": "Lionel",
            "last_name": "Messi",
            "avatar": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRQnwac8XhTZ6BR3-v2s2qcs6ws_6s7qy2oWA&usqp=CAU"
        },
        {
            "id": 9,
            "email": "mbappe@hotmail.com",
            "first_name": "Kylian",
            "last_name": "Mbappé",
            "avatar": "https://conteudo.imguol.com.br/c/esporte/57/2021/08/13/mbappe-pode-deixar-o-psg-mas-inglaterra-nao-sera-seu-destino-1628886199972_v2_450x337.jpg"
        },
        {
            "id": 10,
            "email": "neymar@hotmail.com",
            "first_name": "Neymar",
            "last_name": "Junior",
            "avatar": "https://images.ctfassets.net/3mv54pzvptwz/5NlCRlTMSziMaRUQtvaCPi/b908f9aa38ad78e930dc77c7a90cdc7f/NJR_GOAL_OF_THE_WEEK_PSG.jpg"
        },
        {
            "id": 11,
            "email": "ibrahimovic@hotmail.com",
            "first_name": "Zlatan",
            "last_name": "Ibrahimović",
            "avatar": "https://tmssl.akamaized.net/images/foto/normal/zlatan-ibrahimovic-ac-mailand-1603008323-49388.jpg?lm=1603008348"
        },
        {
            "id": 12,
            "email": "gareth@hotmail.com",
            "first_name": "Gareth",
            "last_name": "Bale",
            "avatar": "https://sportbuzz.uol.com.br/media/_versions/bale_gVFiTly_widexl.jpg"
        }
    ];



//item com uma arrow function
/*const meuItemObj = ({item}) => (
  <View>
      <Text style={styles.paragraph}>{item.title}</Text>
    </View>
)*/



export default function App() {

  //função que renderiza cada item do FlatList
  function meuItem({item}){
    let nomeCompleto = item.first_name + " " + item.last_name
    
    return(
      <Pessoa nome={nomeCompleto} 
              link={item.avatar}
              email={item.email}
      />
    )
  }
  

  return (

    <View style={styles.container}>

      <FlatList
        data={DATA}
        renderItem={meuItem}
        keyExtractor={item => item.id}
      />
      
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    margin: 12,
    padding: 12,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    backgroundColor: 'pink'
  },
  tinyLogo: {
    width: 50,
    height: 50,
    alignSelf: 'center'
  },
  modalView: {
    margin: 20,
    backgroundColor: "white",
    borderRadius: 20,
    padding: 35,
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5
  },
  centeredView: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
});
